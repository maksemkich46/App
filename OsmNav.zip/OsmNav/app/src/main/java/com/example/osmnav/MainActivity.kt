@file:OptIn(ExperimentalMaterial3ExpressiveApi::class)
package com.example.osmnav

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.speech.tts.TextToSpeech
import java.util.Locale
import kotlinx.coroutines.delay
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.compose.ui.platform.LocalLifecycleOwner
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Polyline
import org.osmdroid.views.overlay.mylocation.GpsMyLocationProvider
import org.osmdroid.views.overlay.mylocation.MyLocationNewOverlay
import java.net.URL
import java.net.URLEncoder

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Configuration.getInstance().userAgentValue = packageName // нужно для тайлов OSM
        enableEdgeToEdge()
        setContent { NavTheme { App() } }
    }
}

/** MD3 Expressive + Monet (dynamic color на Android 12+) */
@Composable
fun NavTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val ctx = LocalContext.current
    val scheme = when {
        Build.VERSION.SDK_INT >= 31 -> if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        dark -> darkColorScheme()
        else -> lightColorScheme()
    }
    MaterialExpressiveTheme(colorScheme = scheme, motionScheme = MotionScheme.expressive(), content = content)
}

data class Place(val name: String, val lat: Double, val lon: Double)
data class Step(val text: String, val point: GeoPoint, val arrive: Boolean)
data class Route(val points: List<GeoPoint>, val meters: Double, val seconds: Double, val steps: List<Step>)

fun ruText(type: String, mod: String?, name: String, exit: Int): String {
    val on = if (name.isNotBlank()) " на $name" else ""
    val turn = when (mod) {
        "left" -> "поверните налево"; "right" -> "поверните направо"
        "slight left" -> "примите левее"; "slight right" -> "примите правее"
        "sharp left" -> "поверните резко налево"; "sharp right" -> "поверните резко направо"
        "uturn" -> "развернитесь"; else -> "продолжайте прямо"
    }
    return when (type) {
        "arrive" -> "вы прибыли в пункт назначения"
        "roundabout", "rotary", "roundabout turn" -> "на круговом движении езжайте по $exit-му съезду$on"
        "fork" -> "держитесь ${if (mod?.contains("left") == true) "левее" else "правее"}$on"
        "continue", "new name" -> "продолжайте прямо$on"
        else -> turn + (if (mod == "uturn") "" else on)
    }
}

private fun http(url: String): String =
    (URL(url).openConnection() as java.net.HttpURLConnection).run {
        setRequestProperty("User-Agent", "OsmNav/1.0 (android)")
        inputStream.bufferedReader().readText()
    }

suspend fun search(q: String): List<Place> = withContext(Dispatchers.IO) {
    val arr = JSONArray(http("https://nominatim.openstreetmap.org/search?format=json&limit=6&q=" + URLEncoder.encode(q, "UTF-8")))
    (0 until arr.length()).map { arr.getJSONObject(it) }
        .map { Place(it.getString("display_name"), it.getString("lat").toDouble(), it.getString("lon").toDouble()) }
}

// Демо-сервер OSRM: для личного использования. Для продакшена — свой OSRM/Valhalla/GraphHopper.
suspend fun route(a: GeoPoint, b: GeoPoint): Route? = withContext(Dispatchers.IO) {
    val u = "https://router.project-osrm.org/route/v1/driving/${a.longitude},${a.latitude};${b.longitude},${b.latitude}?overview=full&geometries=geojson&steps=true&language=ru"
    val r = JSONObject(http(u)).optJSONArray("routes")?.optJSONObject(0) ?: return@withContext null
    val c = r.getJSONObject("geometry").getJSONArray("coordinates")
    val st = r.getJSONArray("legs").getJSONObject(0).getJSONArray("steps")
    val steps = (0 until st.length()).map { st.getJSONObject(it) }.filter { it.getJSONObject("maneuver").getString("type") != "depart" }.map {
        val m = it.getJSONObject("maneuver"); val loc = m.getJSONArray("location")
        val t = m.getString("type")
        Step(ruText(t, m.optString("modifier", "").ifEmpty { null }, it.optString("name", ""), m.optInt("exit", 1)),
            GeoPoint(loc.getDouble(1), loc.getDouble(0)), t == "arrive")
    }
    Route((0 until c.length()).map { GeoPoint(c.getJSONArray(it).getDouble(1), c.getJSONArray(it).getDouble(0)) },
        r.getDouble("distance"), r.getDouble("duration"), steps)
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var query by remember { mutableStateOf("") }
    var results by remember { mutableStateOf(listOf<Place>()) }
    var dest by remember { mutableStateOf<Place?>(null) }
    var info by remember { mutableStateOf<Route?>(null) }
    var loading by remember { mutableStateOf(false) }
    var locOverlay by remember { mutableStateOf<MyLocationNewOverlay?>(null) }
    var navigating by remember { mutableStateOf(false) }
    var hint by remember { mutableStateOf("") }
    val tts = remember {
        var t: TextToSpeech? = null
        t = TextToSpeech(ctx) { if (it == TextToSpeech.SUCCESS) t?.language = Locale("ru", "RU") }
        t
    }
    DisposableEffect(Unit) { onDispose { tts.stop(); tts.shutdown() } }
    fun say(t: String) { hint = t; tts.speak(t, TextToSpeech.QUEUE_FLUSH, null, "nav") }

    val map = remember {
        MapView(ctx).apply {
            setTileSource(TileSourceFactory.MAPNIK)
            setMultiTouchControls(true)
            keepScreenOn = true
            controller.setZoom(14.0)
            controller.setCenter(GeoPoint(55.7558, 37.6173))
        }
    }
    fun enableLocation() {
        if (locOverlay != null) return
        val o = MyLocationNewOverlay(GpsMyLocationProvider(ctx), map).apply { enableMyLocation(); enableFollowLocation() }
        map.overlays.add(o); locOverlay = o
    }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if (it.values.any { g -> g }) enableLocation()
    }
    LaunchedEffect(Unit) {
        permLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
    }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val ob = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_RESUME) map.onResume()
            if (e == Lifecycle.Event.ON_PAUSE) map.onPause()
        }
        owner.lifecycle.addObserver(ob)
        onDispose { owner.lifecycle.removeObserver(ob); map.onDetach() }
    }

    LaunchedEffect(navigating, info) {
        val r = info
        if (!navigating || r == null) return@LaunchedEffect
        var i = 0; var far = false; var near = false
        say("Начинаем движение")
        while (i < r.steps.size) {
            delay(1000)
            val me = locOverlay?.myLocation ?: continue
            val s = r.steps[i]
            val d = me.distanceToAsDouble(s.point)
            map.controller.animateTo(me)
            if (!far && d < 400 && d > 80) { far = true; say("Через ${(d / 50).toInt() * 50} метров, ${s.text}") }
            if (!near && d <= 80) { near = true; far = true; say(s.text) }
            if (d < 25) {
                if (s.arrive) { navigating = false; break }
                i++; far = false; near = false
            }
        }
        navigating = false
    }

    fun go(p: Place) {
        dest = p; results = emptyList(); loading = true
        scope.launch {
            val from = locOverlay?.myLocation ?: (map.mapCenter as GeoPoint)
            val to = GeoPoint(p.lat, p.lon)
            val r = runCatching { route(from, to) }.getOrNull()
            map.overlays.removeAll { it is Polyline || it is Marker }
            map.overlays.add(Marker(map).apply { position = to; title = p.name })
            if (r != null) {
                map.overlays.add(Polyline(map).apply { setPoints(r.points); outlinePaint.strokeWidth = 14f })
                map.zoomToBoundingBox(org.osmdroid.util.BoundingBox.fromGeoPoints(r.points), true, 150)
            } else map.controller.animateTo(to)
            info = r; loading = false; map.invalidate()
        }
    }

    Box(Modifier.fillMaxSize()) {
        AndroidView(factory = { map }, modifier = Modifier.fillMaxSize())

        Column(Modifier.align(Alignment.TopCenter).statusBarsPadding().padding(12.dp)) {
            TextField(
                value = query, onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth(), singleLine = true, shape = CircleShape,
                placeholder = { Text("Куда едем?") },
                leadingIcon = { Icon(Icons.Default.Search, null) },
                colors = TextFieldDefaults.colors(focusedIndicatorColor = androidx.compose.ui.graphics.Color.Transparent,
                    unfocusedIndicatorColor = androidx.compose.ui.graphics.Color.Transparent),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = {
                    loading = true
                    scope.launch { results = runCatching { search(query) }.getOrDefault(emptyList()); loading = false }
                })
            )
            if (results.isNotEmpty()) {
                ElevatedCard(Modifier.padding(top = 8.dp).heightIn(max = 320.dp)) {
                    LazyColumn {
                        items(results) { p ->
                            ListItem(headlineContent = { Text(p.name, maxLines = 2) },
                                leadingContent = { Icon(Icons.Default.Place, null) },
                                modifier = Modifier.fillMaxWidth().then(Modifier),
                                colors = ListItemDefaults.colors(containerColor = androidx.compose.ui.graphics.Color.Transparent))
                            TextButton(onClick = { go(p) }, modifier = Modifier.padding(start = 8.dp)) { Text("Построить маршрут") }
                            HorizontalDivider()
                        }
                    }
                }
            }
        }

        Column(Modifier.align(Alignment.BottomEnd).navigationBarsPadding().padding(12.dp), horizontalAlignment = Alignment.End) {
            FloatingActionButton(onClick = { locOverlay?.myLocation?.let { map.controller.animateTo(it) } ?: enableLocation() }) {
                Icon(Icons.Default.MyLocation, "Моя позиция")
            }
            Spacer(Modifier.height(12.dp))
            if (loading) LoadingIndicator(Modifier.align(Alignment.CenterHorizontally))
            val d = dest
            if (d != null) {
                ElevatedCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text(d.name, style = MaterialTheme.typography.titleMedium, maxLines = 2)
                        info?.let {
                            Text("%.1f км • %d мин".format(it.meters / 1000, (it.seconds / 60).toInt()),
                                style = MaterialTheme.typography.headlineSmall, color = MaterialTheme.colorScheme.primary)
                        }
                        if (navigating && hint.isNotEmpty()) Text(hint, style = MaterialTheme.typography.bodyLarge)
                        Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (info != null) Button(onClick = {
                                if (navigating) { navigating = false; tts.stop() } else navigating = true
                            }) { Icon(if (navigating) Icons.Default.Stop else Icons.Default.Navigation, null) ; Spacer(Modifier.width(8.dp)); Text(if (navigating) "Стоп" else "Поехали") }
                            FilledTonalButton(onClick = {
                                runCatching {
                                    ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("geo:${d.lat},${d.lon}?q=${d.lat},${d.lon}"))
                                        .setPackage("app.organicmaps"))
                                }
                            }) { Icon(Icons.Default.OpenInNew, null); Spacer(Modifier.width(8.dp)); Text("Organic Maps") }
                            OutlinedButton(onClick = {
                                navigating = false; dest = null; info = null; map.overlays.removeAll { it is Polyline || it is Marker }; map.invalidate()
                            }) { Text("Сбросить") }
                        }
                    }
                }
            }
        }
    }
}
